package com.exedosoft.plat.ui.jquery.grid;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.exedosoft.plat.ExedoException;
import com.exedosoft.plat.SessionContext;
import com.exedosoft.plat.action.DOAbstractAction;
import com.exedosoft.plat.bo.BOInstance;
import com.exedosoft.plat.bo.DOService;
import com.exedosoft.plat.ui.DOFormModel;
import com.exedosoft.plat.ui.DOGridModel;
import com.exedosoft.plat.ui.DOIModel;
import com.exedosoft.plat.ui.DOPaneModel;
import com.exedosoft.plat.ui.DOViewTemplate;
import com.exedosoft.plat.util.DOGlobals;
import com.exedosoft.plat.util.StringUtil;

/**
 * @author aa
 */
public class GridListCX2 extends DOViewTemplate {

	private static Log log = LogFactory.getLog(GridListCX2.class);

	public GridListCX2() {
		this.templateFile = "grid/GridListCX2.ftl";
	}
	public String excute() throws ExedoException {
		return null;
	}
	@Override
	public Map<String, Object> putData(DOIModel doimodel) {

		DOGridModel gm = (DOGridModel) doimodel;
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("model", gm);
		data.put("data", getListData(gm, data));
		data.put("webmodule", DOGlobals.URL);
		data.put("contextPath", DOGlobals.PRE_FULL_FOLDER);
		if (gm.getContainerPane() != null) {
			data.put("pmlName", gm.getContainerPane().getName());
		}
		data.put("formName", "a" + gm.getObjUid());

		if (gm.getContainerPane() != null
				&& gm.getContainerPane().getParent() != null) {

			// //�Զ��ж��������
			List children = gm.getContainerPane().getParent()
					.retrieveChildren();

			if (children != null && children.size() == 2) {
				DOPaneModel conditionPane = (DOPaneModel) children.get(0);
				DOPaneModel resultModel = (DOPaneModel) children.get(1);
				if (conditionPane != null) {
					if (conditionPane.getDOGridModel() != null) {
						String formName = "a"
								+ conditionPane.getDOGridModel().getObjUid();
						data.put("formName", formName);
					}
				}

			}

			// //���������������壨����ĺ����� ӵ�б�������壩
			DOPaneModel hpm = gm.getContainerPane().getHiddenPane();
			if (hpm != null) {
				if (hpm.getDOGridModel() != null) {
					String formName = "a" + hpm.getDOGridModel().getObjUid();
					data.put("formName", formName);
				}
			}

		}

		return data;
	}

	public static List<BOInstance> getListData(DOGridModel gridModel,
			Map<String, Object> data) {
		boolean isnull = true;
		BOInstance actionBi= DOGlobals.getInstance().getSessoinContext().getFormInstance();//ff80808131b78b9c0131b7c53eb50073
		//DOBO dobo = DOBO.getDOBOByID("ff80808131b78b9c0131b7c53eb50073");
		BOInstance actionBi1= DOGlobals.getInstance().getSessoinContext().getFormInstance();
		//rollarchcode=, leasebegin2=, archtype=,
		Map cxMap = new HashMap();
		if(actionBi != null) {
			String rollarchcode = actionBi.getValue("rollarchcode");
			if(rollarchcode == null || "".equals(rollarchcode.trim())) {
				if(isnull)
				   isnull = true;
			} else {
				cxMap.put("rollarchcode", rollarchcode);
				 isnull = false;
			}
			String leasebegin2 = actionBi.getValue("leasebegin2");
			if(leasebegin2 == null || "".equals(leasebegin2.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("leasebegin2", leasebegin2);
					 isnull = false;
			}
			String archtype = actionBi.getValue("archtype");
			if(archtype == null || "".equals(archtype.trim())) {
				if(isnull)
					   isnull = true;
			} else {
					cxMap.put("archtype", archtype);
					 isnull = false;
			}
			//leaseend=, fondscode=, secretdegree=,
			String leaseend = actionBi.getValue("leaseend");
			if(leaseend == null || "".equals(leaseend.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("leaseend", leaseend);
					 isnull = false;
			}
			String fondscode = actionBi.getValue("fondscode");
			if(fondscode == null || "".equals(fondscode.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("fondscode", fondscode);
					 isnull = false;
			}
			String secretdegree = actionBi.getValue("secretdegree");
			if(secretdegree == null || "".equals(secretdegree.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("secretdegree", secretdegree);
					 isnull = false;
			}
			//filingyear=, contractcode=, keyinman=, 
			String filingyear = actionBi.getValue("filingyear");
			if(filingyear == null || "".equals(filingyear.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("filingyear", filingyear);
					 isnull = false;
			}
			String contractcode = actionBi.getValue("contractcode");
			if(contractcode == null || "".equals(contractcode.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("contractcode", contractcode);
					 isnull = false;
			}
			String keyinman = actionBi.getValue("keyinman");
			if(keyinman == null || "".equals(keyinman.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("keyinman", keyinman);
					 isnull = false;
			}
			//tenant=, keyintime2=, dept_uid=, 
			String tenant = actionBi.getValue("tenant");
			if(tenant == null || "".equals(tenant.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("tenant", tenant);
					 isnull = false;
			}
			String keyintime2 = actionBi.getValue("keyintime2");
			if(keyintime2 == null || "".equals(keyintime2.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("keyintime2", keyintime2);
					 isnull = false;
			}
			String dept_uid = actionBi.getValue("dept_uid");
			if(dept_uid == null || "".equals(dept_uid.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("dept_uid", dept_uid);
					 isnull = false;
			}
			//titlename=, itemname=, archsubtype=, 
			String titlename = actionBi.getValue("titlename");
			if(titlename == null || "".equals(titlename.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("titlename", titlename);
					 isnull = false;
			}
			String itemname = actionBi.getValue("itemname");
			if(itemname == null || "".equals(itemname.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("itemname", itemname);
					 isnull = false;
			}
			String archsubtype = actionBi.getValue("archsubtype");
			if(archsubtype == null || "".equals(archsubtype.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("archsubtype", archsubtype);
					 isnull = false;
			}
			//keyintime=, leasebegin=, unit=,
			String keyintime = actionBi.getValue("keyintime");
			if(keyintime == null || "".equals(keyintime.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("keyintime", keyintime);
					 isnull = false;
			}
			String leasebegin = actionBi.getValue("leasebegin");
			if(leasebegin == null || "".equals(leasebegin.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("leasebegin", leasebegin);
					 isnull = false;
			}
			String unit = actionBi.getValue("unit");
			if(unit == null || "".equals(unit.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("unit", unit);
					 isnull = false;
			}
			//filingyear2=, leaseend2=, retainterm=, 
			String filingyear2 = actionBi.getValue("filingyear2");
			if(filingyear2 == null || "".equals(filingyear2.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("filingyear2", filingyear2);
					 isnull = false;
			}
			String leaseend2 = actionBi.getValue("leaseend2");
			if(leaseend2 == null || "".equals(leaseend2.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("leaseend2", leaseend2);
					 isnull = false;
			}
			String retainterm = actionBi.getValue("retainterm");
			if(retainterm == null || "".equals(retainterm.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("retainterm", retainterm);
					 isnull = false;
			}
			
			String ywmanager = actionBi.getValue("ywmanager");
			if(ywmanager == null || "".equals(ywmanager.trim())) {
				if(isnull)
					   isnull = true;
			} else {
				cxMap.put("ywmanager", ywmanager);
					 isnull = false;
			}
		}
		
		
		List<BOInstance> listAll = new ArrayList<BOInstance>();
		String type = "";
		String sql = null;
		String mainSql = gridModel.getName();
		if (mainSql != null) {
			if (mainSql.endsWith("ps")) {
				type = "ps";
			} else if (mainSql.endsWith("bl")) {
				type = "bl";
			} else if (mainSql.endsWith("ss")) {
				type = "ss";
			} else if (mainSql.endsWith("zh")) {
				type = "zh";
			} else {
				type = "fk";
			}
		}
		
		
		if(isnull) {
			/**
			 * �����ѯ������Ϊ�գ�����ʾ���������䱾���ŵļ�¼��¼����Ա¼���¼
			 */
			
			//��ȡ����
			String dept_uid = DOGlobals.getInstance().getSessoinContext().getUser().getValue("deptuid");
			
			
			//��ȡ��ɫ
			String roles = DOGlobals.getInstance().getSessoinContext()
			.getInstance().getUser().getValue("roles");
			
			String larchtype = null;
			if ("fk".equals(type)) {
				larchtype = "2c90b0482f0977b3012f0a735e5800cf";
			} else if ("ps".equals(type)) {
				larchtype = "2c90b0482f0977b3012f0a73fe7100d0";
			} else if ("bl".equals(type)) {
				larchtype = "2c90b0482f0977b3012f0a75c59400d1";
			} else if ("ss".equals(type)) {
				larchtype = "2c90b0482f0977b3012f0a7638ff00d2";
			} else if ("zh".equals(type)) {
				larchtype = "2c90b0482f0977b3012f0a76846000d3";
			}
			String morenSql = "architem_auto_condition_arch_2_moren";
			//�ʲ�����
			if("2c90b1b02f0b4b7e012f0b8934cf002f".equals(dept_uid)) {
				morenSql = "architem_auto_condition_arch_2_moren_zcb";
			}
			//�ͻ�����
			else if(roles.indexOf("40288031287fd27f01287fe800210010")!=-1 && "fk".equals(type)) {
				morenSql = "architem_auto_condition_arch_2_moren_kehujingli";
			} 
			//�����
			else if(roles.indexOf("402880fd32b3474c0132b3dc13640018")!=-1 && "ps".equals(type)) {
				morenSql = "architem_auto_condition_arch_2_moren_pingshenguan";
			}	
			//��˾�쵼
			else if(roles.indexOf("402880fd321ec69001321ed300d30004")!=-1) {
				morenSql = "architem_auto_condition_gongsilingdao";
			}	
			DOService linkser = DOService
					.getService(morenSql);

			int pageNo = 1;
			int pageNum = 10;
			
			if (gridModel.getRowSize() != null) {
				pageNum = gridModel.getRowSize().intValue();
			}
			
			if (DOGlobals.getInstance().getSessoinContext().getFormInstance() != null
					&& DOGlobals.getInstance().getSessoinContext()
							.getFormInstance().getValue("pageNo") != null) {
				try {
					pageNo = Integer.parseInt(DOGlobals.getInstance()
							.getSessoinContext().getFormInstance()
							.getValue("pageNo"));
				} catch (Exception e) {

				}
			}

			Map map = new HashMap();
			map.put("archtype", larchtype);	
			List<BOInstance> listsize = new ArrayList<BOInstance>();
			listsize = linkser.invokeSelect(map);
			int resultSize = 0;
			if(listsize != null)
				resultSize = listsize.size();
			int pageSize = StringUtil.getPageSize(resultSize, pageNum);
			data.put("rowSize", pageNum);
			data.put("pageSize", pageSize);
			data.put("pageNo", pageNo);
			data.put("resultSize", resultSize);
			linkser.setParaMap(map);
			listAll = linkser.invokeSelect(pageNo, pageNum);
		}else {
			//���ڲ�ѯ����������ѯ��������
			if ("fk".equals(type)) {
				sql = "architem_auto_condition_arch_cx_2";
			} else if ("ps".equals(type)) {
				sql = "architem_auto_condition_arch_cx_2_ps";
			} else if ("bl".equals(type)) {
				sql = "architem_auto_condition_arch_cx_2_bl";
			} else if ("ss".equals(type)) {
				sql = "architem_auto_condition_arch_cx_2_ss";
			} else if ("zh".equals(type)) {
				sql = "architem_auto_condition_arch_cx_2_zh";
			}
			DOService linkser = DOService.getService(sql);
			
			
			int pageNo = 1;
			int pageNum = 10;

			if (gridModel.getRowSize() != null) {
				pageNum = gridModel.getRowSize().intValue();
			}
			
			if (DOGlobals.getInstance().getSessoinContext().getFormInstance() != null
					&& DOGlobals.getInstance().getSessoinContext()
							.getFormInstance().getValue("pageNo") != null) {
				try {
					DOGlobals go = DOGlobals.getInstance();
					SessionContext sess = DOGlobals.getInstance()
							.getSessoinContext();
					BOInstance bi = DOGlobals.getInstance().getSessoinContext()
							.getFormInstance();

					pageNo = Integer.parseInt(DOGlobals.getInstance()
							.getSessoinContext().getFormInstance()
							.getValue("pageNo"));
				} catch (Exception e) {

				}
			}


			data.put("rowSize", pageNum);
			List<BOInstance> listsize = new ArrayList<BOInstance>();
			listsize = linkser.invokeSelect(cxMap);
			int resultSize = 0;
			if(listsize != null)
				resultSize = listsize.size();
			int pageSize = StringUtil.getPageSize(resultSize, pageNum);
			data.put("pageSize", pageSize);
			data.put("resultSize", resultSize);
			data.put("pageNo", pageNo);
			linkser.setParaMap(cxMap);
			listAll = linkser.invokeSelect(pageNo, pageNum);
		}


		// ///�����ڶ�����ͳ���ã�
		DOService secondService = gridModel.getSecondService();
		if (secondService != null) {
			List secondResult = secondService.invokeSelect();
			if (secondResult.size() > 0) {
				BOInstance statistics = (BOInstance) secondResult.get(0);
				data.put("statistics", statistics.getMap());
				StringBuilder sb = new StringBuilder();
				List<DOFormModel> listFm = gridModel
						.getStatisticOutGridFormLinks();
				if (listFm != null && listFm.size() > 0) {
					for (Iterator<DOFormModel> it = listFm.iterator(); it
							.hasNext();) {
						DOFormModel aFm = it.next();
						aFm.setData(statistics);
						sb.append("&nbsp;&nbsp;&nbsp;&nbsp;")
								.append(aFm.getL10n()).append("��")
								.append(aFm.getValue())
								.append("&nbsp;&nbsp;&nbsp;&nbsp;");
					}
				}
				data.put("statistics_details", sb.toString());

			}
		}

		return listAll;
	}

}
